tar cavf swapspace-1.11.tar.gz --exclude-vcs .
